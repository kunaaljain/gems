


(function() {
var B=window.apture,A=window.apture=B||{};

if(!A.isApp){
    A.userCookieId="q9fDFLSryn";A.prefs=null;A.referer=null;A.visitId=265616076290764;A.abtests=null;

    A.barColor="#d9ebf8";
    A.barTitleColor="#000";
    A.textShadowColor="#fff";    
    A.capabilities = 32;
}


if (!B){ (function(s){var b=eval("(/*@cc_on!@*/0?(window.XMLHttpRequest/*@cc_on&&@_jscript_version>=5.7@*/?'ie7':null):(window.navigator.userAgent.toLowerCase().search(/iphone|ipad|android/)>-1)?null:(document.childNodes&&!document.all&&!navigator.taintEnabled)?'khtml':(document.getBoxObjectFor||(window.mozInnerScreenX===0||window.mozInnerScreenX))?'gecko':'unk')");if(b){s.type='text/javascript';s.charset='utf-8';s.src="http://cdn.apture.com/media/storage."+b+".js?v=21265569";s.defer='true';(document.getElementsByTagName("head").item(0)||document.body).appendChild(s)}})(document.createElement('script')) }
})();
