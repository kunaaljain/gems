// JavaScript Document
$(document).ready(function(){
					   
$("#b1").mouseover(function(){
	$("#b1").addClass('sel');
	$("#b2, #b3, #b4, #b5").removeClass('sel');
	
	$("#a1").show();
	$("#a2, #a3, #a4, #a5").hide();
   });


$("#b2").mouseover(function(){
	$("#b2").addClass('sel');
	$("#b1, #b3, #b4, #b5").removeClass('sel');
	
	$("#a2").show();
	$("#a1, #a3, #a4, #a5").hide();
   });

$("#b3").mouseover(function(){
	$("#b3").addClass('sel');
	$("#b1, #b2, #b4, #b5").removeClass('sel');
	
	$("#a3").show();
	$("#a1, #a2, #a4, #a5").hide();
   });

$("#b4").mouseover(function(){
	$("#b4").addClass('sel');
	$("#b1, #b2, #b3, #b5").removeClass('sel');
	
	$("#a4").show();
	$("#a1, #a2, #a3, #a5").hide();
   });

$("#b5").mouseover(function(){
	$("#b5").addClass('sel');
	$("#b1, #b2, #b3, #b4").removeClass('sel');
	
	$("#a5").show();
	$("#a1, #a2, #a3, #a4").hide();
   });



//login Box Pop up


	       $("#login_link").click(function(){
            if ($("#lpopup").is(':hidden'))
				{
                	$("#lpopup").slideDown("fast");
				}
            else{
                $("#lpopup").slideUp("fast");
            }
            return false;
        });

        $('#lpopup').click(function(e) {
            e.stopPropagation();
        });
        $(document).click(function() {
            $('#lpopup').slideUp("fast");
        });
		
		$("#lclose").click(function(){
				$('#lpopup').slideUp("fast");
									
		});
	
	
		
		

// Text Box js start

$("#lid").focus(function(){ 
						
    if($(this).val() == $(this).attr('defaultValue'))
    {
		$(this).val('');
		$("#lid").addClass('imgNone');
	}
});

$("#lid").blur(function(){
    if($(this).val() == $(this).attr('defaultValue'))
    {
		$(this).val('');
		$("#lid").removeClass('imgNone');
	}
});

$("#lpwd").focus(function(){ 
						
    if($(this).val() == $(this).attr('defaultValue'))
    {
		$(this).val('');
		$("#lpwd").addClass('imgNone');
	}
});

$("#lpwd").blur(function(){
    if($(this).val() == $(this).attr('defaultValue'))
    {
		$(this).val('');
		$("#lpwd").removeClass('imgNone');
	}
});



$("#email").focus(function(){ 
	
    if($(this).val() == $(this).attr('defaultValue'))
    {
		$(this).val('');
		$("#email").addClass('imgNone1');
	}
});

$("#email").blur(function(){
    if($(this).val() == $(this).attr('defaultValue'))
    {
		$(this).val('');
		$("#email").removeClass('imgNone1');
	}
});

$("#password").focus(function(){ 
						
    if($(this).val() == $(this).attr('defaultValue'))
    {
		$(this).val('');
		$("#password").addClass('imgNone1');
	}
});

$("#password").blur(function(){
    if($(this).val() == $(this).attr('defaultValue'))
    {
		$(this).val('');
		$("#password").removeClass('imgNone1');
	}
});


});