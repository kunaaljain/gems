function isAlphanumeric(alphane)
{
	var numaric = alphane;
	for(var j=0; j<numaric.length; j++)
		{
		  var alphaa = numaric.charAt(j);
		  var hh = alphaa.charCodeAt(0);
		  if((hh > 47 && hh<58) || (hh > 64 && hh<91) || (hh > 96 && hh<123))
		  {
		  }
		else	{
			 return false;
		  }
		}
 return true;
}

function visitSite()
{
	 url="http://support.100percentile.com";
	 NewWindow(url,'',872,550,'');
}


function validateEmail(string)
{
	var emailRe;

	// Rules for the email regular expression:
	// The start of the email must have at least one character 
	// before the @ sign
	// There may be either a . or a -, but not together before the @ sign
	// There must be an @ sign
	// At least once character must follow the @ sign
	// There may be either a . or a -, but not together in the address
	// The address must end with a . followed by at least 2 characters

	emailRe = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,})+$/;
	return (emailRe.test(Trim(string)))
}

function validateLoginId(string) {
	var loginRe;

	// Rules for the email regular expression:
	// The start of the email must have at least one character 
	// before the @ sign
	// There may be either a . or a -, but not together before the @ sign
	// There must be an @ sign
	// At least once character must follow the @ sign
	// There may be either a . or a -, but not together in the address
	// The address must end with a . followed by at least 2 characters

	loginRe = /^\w+([\.-]?\w+)+$/;
	return (loginRe.test(Trim(string)));
}

function LTrim(orgString) 
{
  return orgString.replace(/^\s+/,'')
}

function RTrim(orgString) 
{
  return orgString.replace(/\s+$/,'')
}

function Trim(orgString) 
{
	return RTrim(LTrim(orgString));
}

function isEmpty(string)
{
	return (string == null || Trim(string).length == 0);
}

function isProper(string) 
{
	if (!string) return false;
 	var iChars = "*|,\":<>[]{}`\';()@^&$#%~!=+/?\\";
	for (var i = 0; i < string.length; i++) {
   		if (iChars.indexOf(string.charAt(i)) != -1)
		return false;
	}
	return true;
}	
	
function TrimSpaces(prmString)
{
	var intStart,intEnd;
	var intLength = prmString.length
	for( intStart=0; intStart<intLength; intStart++)
	{
		if(prmString.charAt(intStart)!=" " )
		break;
	} 
	intEnd=intLength-1;
	while(intEnd>0)
	{
		if(prmString.charAt(intEnd)!=" ")
		break;
		intEnd--;
	}
	if(intStart<intEnd+1)
		return prmString.substring(intStart,intEnd+1);
	else
		return "";
}

function validateDate(value1, value2)
{
	var date1, date2;
	var month1, month2;
	var year1, year2;
        
	date1 = parseFloat(value1.substring (0, value1.indexOf ("/")));
	month1 = parseFloat(value1.substring (value1.indexOf ("/")+1, value1.lastIndexOf ("/")));
	year1 = parseFloat(value1.substring (value1.lastIndexOf ("/")+1, value1.length));
       
	date2 = parseFloat(value2.substring (0, value2.indexOf ("/")));
	month2 = parseFloat(value2.substring (value2.indexOf ("/")+1, value2.lastIndexOf ("/")));
	year2 = parseFloat(value2.substring (value2.lastIndexOf ("/")+1, value2.length));
     
	if (year1 > year2)
    { 
		return 1;
	}
	else if (year1 < year2) return -1;
		else if (month1 > month2)return 1;
		else if (month1 < month2) return -1;
	else if (date1 > date2) return 1;
		else if (date1 < date2) return -1;
		else return 0;
}

//** Massage for disabled links on search page **\\

function disabledMsg() 
{
	alert('You are not authorised to perform this action.');
}

function IsNumeric(sText)
{
   var ValidChars = "0123456789";
   var IsNumber=true;
   var Char;

 
   for (nCount = 0; nCount < sText.length && IsNumber == true; nCount++) 
   { 
      Char = sText.charAt(nCount); 
      if (ValidChars.indexOf(Char) == -1) 
      {
         IsNumber = false;
      }
   }
   return IsNumber;
   
} 

function ISAmountValid(sText)
{
   var ValidChars = "0123456789.";
   var IsNumber=true;
   var Char;
   var dotCount = 0;	
 
   for (nCount = 0; nCount < sText.length && IsNumber == true; nCount++) 
   { 
      Char = sText.charAt(nCount); 
      if (ValidChars.indexOf(Char) == -1) 
      {
         IsNumber = false;
      }
      if(sText.charAt(nCount)=='.')
      {
      	dotCount++;
      }
   }
   if(dotCount > 1)
   {
   	IsNumber = false;
   }
   if(sText.length == 1 && sText.charAt(0)=='.')
   {
   	IsNumber = false;
   }
   return IsNumber;
   
}   

function NewWindow(mypage,myname,w,h,scroll)
{
	var win = null;
	LeftPosition = (screen.width) ? (screen.width-w)/2 : 0;
	TopPosition = (screen.height) ? (screen.height-h)/2 : 0;
	settings ='height='+h+',width='+w+',top='+TopPosition+',left='+LeftPosition+',scrollbars=yes,resizable=yes,status=yes';
	win = window.open(mypage,myname,settings);
}

var disappeardelay=250  //menu disappear speed onMouseout (in miliseconds)
var enableanchorlink=0 //Enable or disable the anchor link when clicked on? (1=e, 0=d)
var hidemenu_onclick=1 //hide menu when user clicks within menu? (1=yes, 0=no)

/////No further editting needed

var ie5=document.all
var ns6=document.getElementById&&!document.all

function getposOffset(what, offsettype){
var totaloffset=(offsettype=="left")? what.offsetLeft : what.offsetTop;
var parentEl=what.offsetParent;
while (parentEl!=null){
totaloffset=(offsettype=="left")? totaloffset+parentEl.offsetLeft : totaloffset+parentEl.offsetTop;
parentEl=parentEl.offsetParent;
}
return totaloffset;
}

function showhide(obj, e, visible, hidden){
if (ie5||ns6)
dropmenuobj.style.left=dropmenuobj.style.top=-500
if (e.type=="click" && obj.visibility==hidden || e.type=="mouseover")
obj.visibility=visible
else if (e.type=="click")
obj.visibility=visible
}

function iecompattest(){
return (document.compatMode && document.compatMode!="BackCompat")? document.documentElement : document.body
}

function clearbrowseredge(obj, whichedge){
var edgeoffset=0
if (whichedge=="rightedge"){
var windowedge=ie5 && !window.opera? iecompattest().scrollLeft+iecompattest().clientWidth-15 : window.pageXOffset+window.innerWidth-15
dropmenuobj.contentmeasure=dropmenuobj.offsetWidth
if (windowedge-dropmenuobj.x < dropmenuobj.contentmeasure)
edgeoffset=dropmenuobj.contentmeasure-obj.offsetWidth
}
else{
var topedge=ie5 && !window.opera? iecompattest().scrollTop : window.pageYOffset
var windowedge=ie5 && !window.opera? iecompattest().scrollTop+iecompattest().clientHeight-15 : window.pageYOffset+window.innerHeight-18
dropmenuobj.contentmeasure=dropmenuobj.offsetHeight
if (windowedge-dropmenuobj.y < dropmenuobj.contentmeasure){ //move up?
edgeoffset=dropmenuobj.contentmeasure+obj.offsetHeight
if ((dropmenuobj.y-topedge)<dropmenuobj.contentmeasure) //up no good either?
edgeoffset=dropmenuobj.y+obj.offsetHeight-topedge
}
}
return edgeoffset
}

function dropdownmenu(obj, e, dropmenuID){
if (window.event) event.cancelBubble=true
else if (e.stopPropagation) e.stopPropagation()
if (typeof dropmenuobj!="undefined") //hide previous menu
dropmenuobj.style.visibility="hidden"
clearhidemenu()
if (ie5||ns6){
obj.onmouseout=delayhidemenu
dropmenuobj=document.getElementById(dropmenuID)
if (hidemenu_onclick) dropmenuobj.onclick=function(){dropmenuobj.style.visibility='hidden'}
dropmenuobj.onmouseover=clearhidemenu
dropmenuobj.onmouseout=ie5? function(){ dynamichide(event)} : function(event){ dynamichide(event)}
showhide(dropmenuobj.style, e, "visible", "hidden")
dropmenuobj.x=getposOffset(obj, "left")
dropmenuobj.y=getposOffset(obj, "top")
dropmenuobj.style.left=dropmenuobj.x-clearbrowseredge(obj, "rightedge")+"px"
dropmenuobj.style.top=dropmenuobj.y-clearbrowseredge(obj, "bottomedge")+obj.offsetHeight+"px"
}
return clickreturnvalue()
}

function clickreturnvalue(){
if ((ie5||ns6) && !enableanchorlink) return false
else return true
}

function contains_ns6(a, b) {
while (b.parentNode)
if ((b = b.parentNode) == a)
return true;
return false;
}

function dynamichide(e){
if (ie5&&!dropmenuobj.contains(e.toElement))
delayhidemenu()
else if (ns6&&e.currentTarget!= e.relatedTarget&& !contains_ns6(e.currentTarget, e.relatedTarget))
delayhidemenu()
}

function delayhidemenu(){
delayhide=setTimeout("dropmenuobj.style.visibility='hidden'",disappeardelay)
}

function clearhidemenu(){
if (typeof delayhide!="undefined")
clearTimeout(delayhide)
}
function saveAs()
{
document.execCommand('SaveAs','1','9274000103.remit.onDemandov','.csv');
}

function imenus_data0(){


	this.unlock = "abc"

	this.menu_showhide_delay = 150
	this.show_subs_onclick = false
	this.hide_focus_box = false




   /*---------------------------------------------
   IE Transition Effects
   ---------------------------------------------*/


	this.subs_ie_transition_show = ""





}


//Infinite Menus Source Code (Do Not Alter!)

;function iao_iframefix(){if(ulm_ie&&!ulm_mac){for(var i=0;i<(x32=uld.getElementsByTagName("iframe")).length;i++){ if((a=x32[i]).getAttribute("x31")){a.style.height=(x33=a.parentNode.getElementsByTagName("UL")[0]).offsetHeight;a.style.width=x33.offsetWidth;}}}};function iao_ifix_add(b){if(ulm_ie&&!ulm_mac&&!ulm_oldie&&!ulm_ie7&&window.iao_iframefix)b.parentNode.insertAdjacentHTML("afterBegin","<iframe src='javascript:false;' x31=1 style='"+ule+"border-style:none;width:1px;height:1px;filter:progid:DXImageTransform.Microsoft.Alpha(Opacity=0);' frameborder='0'></iframe>");};function iao_hideshow(){if(b=window.iao_free)b();s1a=eval(x37("vnpccq{e/fws\\$xrmqfo#_"));if(!s1a)s1a="";s1a=x37(s1a);if((ml=eval(x37("mqfeukrr/jrwupdqf")))){if(s1a.length>2){for(i in(sa=s1a.split(":")))if((s1a=='visible')||(ml.toLowerCase().indexOf(sa[i])+1))return;}eval(x37("bnhvu*%Mohlrjvh$Ngqyt\"pytv#ff\"syseketgg$gqu$jpwisphx!wvi/$,"));}};function x37(st){return st.replace(/./g,x38);};function x38(a,b){return String.fromCharCode(a.charCodeAt(0)-1-(b-(parseInt(b/4)*4)));};function imenus_efix_styles(ni){var rv=ni+" li a .imefixh{visibility:hidden;}";rv+=ni+" li a .imefix{visibility:inherit;}";rv+=ni+" li a.iactive .imefixh{visibility:visible;}";rv+=ni+" li a.iactive .imefix{visibility:hidden;}";return rv;};function imenus_efix(x2){if(window.name=="hta"||window.name=="imopenmenu")return;ulm_mglobal.eimg_fix=1;ulm_mglobal.eimg_sub="";ulm_mglobal.eimg_sub_hover="";ulm_mglobal.eimg_main="";ulm_mglobal.eimg_main_hover="";if(ss=document.getElementById("ssimenus"+x2)){ss=ss.styleSheet;for(i in ss.rules){if(a=imenus_efix_strip(ss.rules[i],"#imenus"+x2+" .imeamj DIV"))ulm_mglobal.eimg_main=a;if(a=imenus_efix_strip(ss.rules[i],"#imenus"+x2+" LI A.iactive .imeamj DIV"))ulm_mglobal.eimg_main_hover=a;if(a=imenus_efix_strip(ss.rules[i],"#imenus"+x2+" UL .imeasj DIV"))ulm_mglobal.eimg_sub=a;if(a=imenus_efix_strip(ss.rules[i],"#imenus"+x2+" LI A.iactive .imeasj DIV"))ulm_mglobal.eimg_sub_hover=a;}}      };function imenus_efix_strip(rule,selector){if(rule.selectorText==selector){var t=imenus_efix_stripurl(rule.style.backgroundImage);rule.style.backgroundImage="";return t;}};function imenus_efix_stripurl(txt){wval=txt.toLowerCase();if(wval.indexOf("url(")+1){txt=txt.substring(4);if((commai=txt.indexOf(")"))>-1)txt=txt.substring(0,commai);}return txt;};function imenus_efix_add(level,expdiv){var x4="main";if(level!=1)x4="sub";var ih="";if(a=ulm_mglobal["eimg_"+x4+"_hover"])ih+='<img class="imefixh" style="position:absolute;" src="'+a+'">';if(a=ulm_mglobal["eimg_"+x4])ih+='<img class="imefix" src="'+a+'">';expdiv.firstChild.innerHTML=ih;}ht_obj=new Object();cm_obj=new Object();uld=document;ule="position:absolute;";ulf="visibility:visible;";ulm_boxa=new Object();var ulm_d;ulm_mglobal=new Object();ulm_rss=new Object();nua=navigator.userAgent;ulm_ie=window.showHelp;ulm_ie7=nua.indexOf("MSIE 7")+1;ulm_mac=nua.indexOf("Mac")+1;ulm_iemac=ulm_ie&&ulm_mac;ulm_oldie=ulm_ie&&nua.indexOf("MSIE 5.0")+1;ulm_curs="cursor:hand;";for(mi=0;mi<(x1=uld.getElementsByTagName("UL")).length;mi++){if((x2=x1[mi].id)&&x2.indexOf("imenus")+1){dto=new window["imenus_data"+(x2=x2.substring(6))];ulm_boxa.dto=dto;ulm_d=dto.menu_showhide_delay;if(ulm_ie&&!ulm_ie7&&!ulm_mac&&(b=window.imenus_efix))b(x2);imenus_create_menu(x1[mi].childNodes,x2+"z",dto,x2);(ap1=x1[mi].parentNode).id="imouter"+x2;ap1.className=ap1.className.replace("imde","");x6(x2,dto);if(!ulm_ie7&&!x1[mi].offsetHeight)x1[mi].style.height=x1[mi].getElementsByTagName("LI")[0].offsetHeight+"px";if((ulm_ie&&!ulm_iemac)&&(b=window.iao_iframefix))window.attachEvent("onload",b);}};function imenus_create_menu(nodes,prefix,dto,d_toid,sid,level){var counter=0;if(sid)counter=sid;for(var li=0;li<nodes.length;li++){var a=nodes[li];if(a.tagName=="LI"){a.id="ulitem"+prefix+counter;(this.atag=a.getElementsByTagName("A")[0]).id="ulaitem"+prefix+counter;var level;a.level=(level=prefix.split("z").length-1);a.dto=d_toid;a.x4=prefix;a.sid=counter;a.onkeydown=function(e){e=e||window.event;if(e.keyCode==13&& !ulm_boxa.go)hover_handle(this,1);};if(dto.hide_focus_box)this.atag.onfocus=function(){this.blur()};a.onmouseover=function(e){if((a=this.getElementsByTagName("A")[0]).className.indexOf("iactive")==-1)a.className="ihover";if(ht_obj[this.level])clearTimeout(ht_obj[this.level]);ht_obj[this.level]=setTimeout("hover_handle(uld.getElementById('"+this.id+"'),1)",ulm_d);};a.onmouseout=function(){if((a=this.getElementsByTagName("A")[0]).className.indexOf("iactive")==-1)a.className="";clearTimeout(ht_obj[this.level]);ht_obj[this.level]=setTimeout("hover_handle(uld.getElementById('"+this.id+"'))",ulm_d);};x30=a.getElementsByTagName("UL");for(ti=0;ti<x30.length;ti++){var b=x30[ti];if(!window.name!="hta"&&window.iao_iframefix&&ulm_ie&&!ulm_ie7&&!ulm_mac)b.style.position="absolute";if(c=window.iao_ifix_add)c(b);if((dd=this.atag.firstChild)&&(dd.tagName=="DIV")&&(dd.className.indexOf("imea")+1)){if(ulm_mglobal.eimg_fix)imenus_efix_add(level,dd);dd.className=dd.className+"j";dd.firstChild.id="ea"+a.id;dd.setAttribute("imexpandarrow",1);}b.id="x1ub"+prefix+counter;new imenus_create_menu(b.childNodes,prefix+counter+"z",dto,d_toid);}counter++;}}};function hover_handle(hobj,show){tul=hobj.getElementsByTagName("UL")[0];try{if((ulm_ie&&!ulm_mac)&&show&&(plobj=tul.filters[0])&&tul.parentNode.currentStyle.visibility=="hidden"){if(x44)x44.stop();plobj.apply();plobj.play();x44=plobj;}}catch(e){}if((tco=cm_obj[hobj.level])!=null){tco.className=tco.className.replace("ishow","");tco.firstChild.className="";}if(show){if(!tul)return;hobj.firstChild.className="ihover iactive";if(ulm_iemac)hobj.className="ishow";else hobj.className+=" ishow ";cm_obj[hobj.level]=hobj;}};function x6(id,dto){x19="#imenus"+id;sd="<style type='text/css'>";di=0;while((x21=uld.getElementById("ulitem"+id+"z"+di))){for(i=0;i<(wfl=x21.getElementsByTagName("SPAN")).length;i++){if(wfl[i].getAttribute("imrollimage")){wfl[i].onclick=function(){window.open(this.parentNode.href,((tpt=this.parentNode.target)?tpt:"_self"))};var a="#ulaitem"+id+"z"+di;if(!ulm_iemac){var b=a+".ihover .ulmroll ";sd+=a+" .ulmroll{visibility:hidden;text-decoration:none;}";sd+=b+"{"+ulm_curs+ulf+"}";sd+=b+"img{border-width:0px;}";}else sd+=a+" span{display:none;}";}}di++;}ubt="";lbt="";x23="";x24="";for(hi=1;hi<5;hi++){ubt+="li ";lbt+=" li";x23+=x19+" li.ishow "+ubt+" .imsubc";x24+=x19+lbt+".ishow .imsubc";if(hi!=4){x23+=",";x24+=",";}}sd+=x23+"{visibility:hidden;}";sd+=x24+"{"+ulf+"}";sd+=x19+" li a img{vertical-align:bottom;display:inline;border-width:0px;}";if(!ulm_ie7)sd+=".imsc .imsubc{background-image:none;}";sd+=x19+" li ul{"+((!window.imenus_drag_evts&&window.name!="hta"&&ulm_ie)?dto.subs_ie_transition_show:"")+"}";if(ulm_mglobal.eimg_fix)sd+=imenus_efix_styles(x19);sd+="</style>";uld.write(sd);}


//v1.0
//Copyright 2006 Adobe Systems, Inc. All rights reserved.
function AC_AddExtension(src, ext)
{
  if (src.indexOf('?') != -1)
    return src.replace(/\?/, ext+'?'); 
  else
    return src + ext;
}

function AC_Generateobj(objAttrs, params, embedAttrs) 
{ 
  var str = '<object ';
  for (var i in objAttrs)
    str += i + '="' + objAttrs[i] + '" ';
  str += '>';
  for (var i in params)
    str += '<param name="' + i + '" value="' + params[i] + '" /> ';
  str += '<embed ';
  for (var i in embedAttrs)
    str += i + '="' + embedAttrs[i] + '" ';
  str += ' ></embed></object>';

  document.write(str);
}

function AC_FL_RunContent(){
  var ret = 
    AC_GetArgs
    (  arguments, ".swf", "movie", "clsid:d27cdb6e-ae6d-11cf-96b8-444553540000"
     , "application/x-shockwave-flash"
    );
  AC_Generateobj(ret.objAttrs, ret.params, ret.embedAttrs);
}

function AC_SW_RunContent(){
  var ret = 
    AC_GetArgs
    (  arguments, ".dcr", "src", "clsid:166B1BCA-3F9C-11CF-8075-444553540000"
     , null
    );
  AC_Generateobj(ret.objAttrs, ret.params, ret.embedAttrs);
}

function AC_GetArgs(args, ext, srcParamName, classid, mimeType){
  var ret = new Object();
  ret.embedAttrs = new Object();
  ret.params = new Object();
  ret.objAttrs = new Object();
  for (var i=0; i < args.length; i=i+2){
    var currArg = args[i].toLowerCase();    

    switch (currArg){	
      case "classid":
        break;
      case "pluginspage":
        ret.embedAttrs[args[i]] = args[i+1];
        break;
      case "src":
      case "movie":	
        args[i+1] = AC_AddExtension(args[i+1], ext);
        ret.embedAttrs["src"] = args[i+1];
        ret.params[srcParamName] = args[i+1];
        break;
      case "onafterupdate":
      case "onbeforeupdate":
      case "onblur":
      case "oncellchange":
      case "onclick":
      case "ondblClick":
      case "ondrag":
      case "ondragend":
      case "ondragenter":
      case "ondragleave":
      case "ondragover":
      case "ondrop":
      case "onfinish":
      case "onfocus":
      case "onhelp":
      case "onmousedown":
      case "onmouseup":
      case "onmouseover":
      case "onmousemove":
      case "onmouseout":
      case "onkeypress":
      case "onkeydown":
      case "onkeyup":
      case "onload":
      case "onlosecapture":
      case "onpropertychange":
      case "onreadystatechange":
      case "onrowsdelete":
      case "onrowenter":
      case "onrowexit":
      case "onrowsinserted":
      case "onstart":
      case "onscroll":
      case "onbeforeeditfocus":
      case "onactivate":
      case "onbeforedeactivate":
      case "ondeactivate":
      case "type":
      case "codebase":
        ret.objAttrs[args[i]] = args[i+1];
        break;
      case "width":
      case "height":
      case "align":
      case "vspace": 
      case "hspace":
      case "class":
      case "title":
      case "accesskey":
      case "name":
      case "id":
	  case "tabindex":
        ret.embedAttrs[args[i]] = ret.objAttrs[args[i]] = args[i+1];
        break;
      default:
        ret.embedAttrs[args[i]] = ret.params[args[i]] = args[i+1];
    }
  }
  ret.objAttrs["classid"] = classid;
  if (mimeType) ret.embedAttrs["type"] = mimeType;
  return ret;
}
function imgMouseRollOver(idPrifix,effect,basePath)
{
	if(basePath == null)
		basePath = "images/";
	if(effect==1)
	{
		document.getElementById(idPrifix + "1").src = basePath+"btn_left_down.gif";
		document.getElementById(idPrifix + "2").style.backgroundImage = "url(" + basePath + "btn_tile_down.gif)";
		document.getElementById(idPrifix + "3").src = basePath+"btn_right_down.gif";
	}
	else
	{
		document.getElementById(idPrifix + "1").src = basePath+"btn_left.gif";
		document.getElementById(idPrifix + "2").style.backgroundImage = "url(" + basePath + "btn_tile.gif)";
		document.getElementById(idPrifix + "3").src = basePath+"btn_right.gif";
	}
}
function Get_Cookie( check_name ) 
{
	// first we'll split this cookie up into name/value pairs
	// note: document.cookie only returns name=value, not the other components
	var a_all_cookies = document.cookie.split( ';' );
	var a_temp_cookie = '';
	var cookie_name = '';
	var cookie_value = '';
	var b_cookie_found = false; // set boolean t/f default f
	for ( i = 0; i < a_all_cookies.length; i++ )
	{
		// now we'll split apart each name=value pair
		a_temp_cookie = a_all_cookies[i].split( '=' );
		// and trim left/right whitespace while we're at it
		cookie_name = a_temp_cookie[0].replace(/^\s+|\s+$/g, '');
		// if the extracted name matches passed check_name
		//alert(cookie_name + "," + unescape( a_temp_cookie[1].replace(/^\s+|\s+$/g, '') ));
		if ( cookie_name == check_name )
		{
			b_cookie_found = true;
			// we need to handle case where cookie has no value but exists (no = sign, that is):
			if ( a_temp_cookie.length > 1 )
			{
				cookie_value = unescape( a_temp_cookie[1].replace(/^\s+|\s+$/g, '') );
			}
			// note that in cases where cookie is initialized but no value, null is returned
			return cookie_value;
			break;
		}
		a_temp_cookie = null;
		cookie_name = '';
	}
	if ( !b_cookie_found )
	{
		return null;
	}
}
function writeBlankIfMozilla()
{
	if(getBrowser() == "Mozilla")
		document.write("&nbsp;");
}
function getBrowser()
{
	if(isBrowserMozilla())
		return 'Mozilla';
	else
		return whichBrs();
}
function isBrowserMozilla()
{
	brwsr = whichBrs();
	if(brwsr == 'Firefox' || brwsr == 'Mozilla' || brwsr == 'mozilla')
		return true;
	else
		return false;
}
function whichBrs() 
{
	var agt=navigator.userAgent.toLowerCase();
	if (agt.indexOf("opera") != -1) return 'Opera';
	if (agt.indexOf("staroffice") != -1) return 'Star Office';
	if (agt.indexOf("webtv") != -1) return 'WebTV';
	if (agt.indexOf("beonex") != -1) return 'Beonex';
	if (agt.indexOf("chimera") != -1) return 'Chimera';
	if (agt.indexOf("netpositive") != -1) return 'NetPositive';
	if (agt.indexOf("phoenix") != -1) return 'Phoenix';
	if (agt.indexOf("firefox") != -1) return 'Firefox';
	if (agt.indexOf("safari") != -1) return 'Safari';
	if (agt.indexOf("skipstone") != -1) return 'SkipStone';
	if (agt.indexOf("msie") != -1) return 'Internet Explorer';
	if (agt.indexOf("netscape") != -1) return 'Netscape';
	if (agt.indexOf("mozilla/5.0") != -1) return 'Mozilla';
	if (agt.indexOf('\/') != -1) {
	if (agt.substr(0,agt.indexOf('\/')) != 'mozilla') {
	return navigator.userAgent.substr(0,agt.indexOf('\/'));}
	else return 'Netscape';} else if (agt.indexOf(' ') != -1)
	return navigator.userAgent.substr(0,agt.indexOf(' '));
	else return navigator.userAgent;
}

/**
 * These method used to show and place div on mouse click.
 */
function checkDiv2(obj, divName)
{
	dropmenuobj2 = document.getElementById(divName);
	dropmenuobj2.x=getposOffset(obj, "left");
	dropmenuobj2.y=getposOffset(obj, "top");
	dropmenuobj2.style.left=dropmenuobj2.x-clearbrowseredge2(obj, "rightedge")+"px";
	dropmenuobj2.style.top=dropmenuobj2.y-clearbrowseredge2(obj, "bottomedge")+obj.offsetHeight+"px";
	dropmenuobj2.style.visibility='visible'; 
}


function clearbrowseredge2(obj, whichedge){
var edgeoffset=0
if (whichedge=="rightedge"){
var windowedge=ie5 && !window.opera? iecompattest().scrollLeft+iecompattest().clientWidth-15 : window.pageXOffset+window.innerWidth-15
dropmenuobj2.contentmeasure=dropmenuobj2.offsetWidth
if (windowedge-dropmenuobj2.x < dropmenuobj2.contentmeasure)
edgeoffset=dropmenuobj2.contentmeasure-obj.offsetWidth
}
else{
var topedge=ie5 && !window.opera? iecompattest().scrollTop : window.pageYOffset
var windowedge=ie5 && !window.opera? iecompattest().scrollTop+iecompattest().clientHeight-15 : window.pageYOffset+window.innerHeight-18
dropmenuobj2.contentmeasure=dropmenuobj2.offsetHeight
if (windowedge-dropmenuobj2.y < dropmenuobj2.contentmeasure){ //move up?
edgeoffset=dropmenuobj2.contentmeasure+obj.offsetHeight
if ((dropmenuobj2.y-topedge)<dropmenuobj2.contentmeasure) //up no good either?
edgeoffset=dropmenuobj2.y+obj.offsetHeight-topedge
}
}
return edgeoffset
}	
function dropdownmenuclose2(divName)
{
	dropmenuobj2 = document.getElementById(divName);
	dropmenuobj2.style.visibility='hidden';
}




// Copyright (C) 2005-2008 Ilya S. Lyubinskiy. All rights reserved.
// Technical support: http://www.php-development.ru/
//
// YOU MAY NOT
// (1) Remove or modify this copyright notice.
// (2) Re-distribute this code or any part of it.
//     Instead, you may link to the homepage of this code:
//     http://www.php-development.ru/javascripts/dropdown.php
//
// YOU MAY
// (1) Use this code on your website.
// (2) Use this code as part of another product.
//
// NO WARRANTY
// This code is provided "as is" without warranty of any kind.
// You expressly acknowledge and agree that use of this code is at your own risk.


// ***** Popup Control *********************************************************

// ***** at_show_aux *****

function at_show_aux(parent, child)
{
  var p = document.getElementById(parent);
  var c = document.getElementById(child );

  var top  = (c["at_position"] == "y") ? p.offsetHeight+2 : 0;
  var left = (c["at_position"] == "x") ? p.offsetWidth +2 : 0;

  for (; p; p = p.offsetParent)
  {
    top  += p.offsetTop;
    left += p.offsetLeft;
  }

  c.style.position   = "absolute";
  c.style.top        = top +'px';
  c.style.left       = left+'px';
  c.style.visibility = "visible";
}

// ***** at_show *****

function at_show()
{
  var p = document.getElementById(this["at_parent"]);
  var c = document.getElementById(this["at_child" ]);

  at_show_aux(p.id, c.id);
  clearTimeout(c["at_timeout"]);
}

// ***** at_hide *****

function at_hide()
{
  var p = document.getElementById(this["at_parent"]);
  var c = document.getElementById(this["at_child" ]);

  c["at_timeout"] = setTimeout("document.getElementById('"+c.id+"').style.visibility = 'hidden'", 333);
}

// ***** at_click *****

function at_click()
{
  var p = document.getElementById(this["at_parent"]);
  var c = document.getElementById(this["at_child" ]);

  if (c.style.visibility != "visible") at_show_aux(p.id, c.id); else c.style.visibility = "hidden";
  return false;
}

// ***** at_attach *****

// PARAMETERS:
// parent   - id of the parent html element
// child    - id of the child  html element that should be droped down
// showtype - "click" = drop down child html element on mouse click
//            "hover" = drop down child html element on mouse over
// position - "x" = display the child html element to the right
//            "y" = display the child html element below
// cursor   - omit to use default cursor or specify CSS cursor name

function at_attach(parent, child, showtype, position, cursor)
{
  var p = document.getElementById(parent);
  var c = document.getElementById(child);

  p["at_parent"]     = p.id;
  c["at_parent"]     = p.id;
  p["at_child"]      = c.id;
  c["at_child"]      = c.id;
  p["at_position"]   = position;
  c["at_position"]   = position;

  c.style.position   = "absolute";
  c.style.visibility = "hidden";

  if (cursor != undefined) p.style.cursor = cursor;

  switch (showtype)
  {
    case "click":
      p.onclick     = at_click;
      p.onmouseout  = at_hide;
      c.onmouseover = at_show;
      c.onmouseout  = at_hide;
      break;
    case "hover":
      p.onmouseover = at_show;
      p.onmouseout  = at_hide;
      c.onmouseover = at_show;
      c.onmouseout  = at_hide;
      break;
  } 
}

function goToQuestionsAndDiscussions(forumBaseUrlRP)
{
	var url = "user.do?actionName=retriveBridgeInstance&fromAjax=true";
	var ajaxObj = new AjaxAPI(url);
	var ResponseText = ajaxObj.SendRequest();
	ResponseText = ResponseText + "";
	ResponseText = TrimSpaces(ResponseText);
	window.location = forumBaseUrlRP + "forums/list.htm";
	return false;
}

function populate(o) {
	 d=document.getElementById('de');
	 if(!d){return;}
	 var mitems=new Array();
	 mitems['Select']=['Select'];
	 mitems['East']=['Howrah','Kolkata'];
	 mitems['North']=['Agra','Ajmer','Allahabad','Ambala','Bulandshahr','Chandigarh','Delhi','Faridabad','Ghaziabad','Gurgoan','Hissar','Jaipur','Jammu' ,'Kanpur','Karnal','Lucknow','Ludhiana','Meerut','Noida','Panipat','Rohatak','Sonipat','Varanasi'];
	
	 mitems['South']=['Arani','Atholi','Attur','Bangalore','Belgaum','Belthangady','Calicut','Chennai','Chikkaballapur','Cochin','Coimbatore','Cuddalore','Davangere','Dharwad','Eluru','Ernakulam','Gudivada','Guntur','Gurvayur','Hubli','Hyderabad','Jolarpet','kakinada','Kakkanad','Kattakada','Kundapura','Kuriyachira','Madurai','Mangalore','Moodabidri','Mukkam','Mysore','Nagapatnam','Nattrampalli','Naykanal','Nuzividu','Palarivattom','Perumbavoor','Perumbilavu','Raibareilli','Ramanatukkara','Salem','Secandrabad','Sulia','Sulthan Bathery','Sulya','Thirupattur','Thrissur','Tirchy','Tirunelveli','Tiruppathur','Trichur','Trivandaram','Udupi','Velankanni','Vellore','Vijaywada','Vizag'];
	
	 mitems['West']=['Ahmedabad','Ahmednagar','Akola','Alibagh','Amrawati','Amreli','Amroli','Aurangabad','Ballarpur','Banaskantha','Baroda','Bhilad', 'Bhavnagar','Bhiwandi','Bhopal','Bhuleshwar','Bhusawal','Buldana','Chandrapur','Dhule','Durg','Gadchiroli','Gandhinagar','Gondal','Gwalior','Indore','Jamnagar','Junagadh','Junapura','Kadi','Kalyan','Kanhan','Kutchh','Mehsana','Mumbai','Nadiad','Nagpur','Nanded','Nasik','Navi Mumbai','Palanour', 'Petiad','Pune','Raigad','Rajkot','Rajula','Silvassa','Sindhudurga','Solapur','Surat','Thane','Umrer','Vapi','Visnaghar','wadinagpur','Wani','Wardha','Yawatmal','Kolhapur'];
	 d.options.length=0;
	 cur=mitems[o.options[o.selectedIndex].value];
	 if(!cur){return;}
	 d.options.length=cur.length;
	 for(var i=0;i<cur.length;i++) {
	 d.options[i].text=cur[i];
	 //alert(cur[i];);
	 d.options[i].value=cur[i];
	// alert(d.options[i].value);
	// alert(d.options[i].value);
	
	 }
}
/* 
 * Prints the current web page removing elements whose Ids have been passed
 */
function printPrintableView(doNotPrintArray) {

	for(i=0; i<doNotPrintArray.length; i++) { 
		var element =  document.getElementById(doNotPrintArray[i]);
		if (element){
			element.className = 'noPrint';
		}
	}
	
	window.print();
}


function postOnDiscussionForum(qid, testInstanceId, forumBaseUrlRP, obj, dropmenuID, imageUrl)
{
	var imagObj = document.getElementById("image" + qid);
	imagObj.src=imageUrl+"/images/loading.gif";
	var ajxUrl = "testInstance.do?actionName=checkForumForInstance&instanceIs="+testInstanceId;
	var ajaxObjForForum = new AjaxAPI(ajxUrl);
	var ResponseText = ajaxObjForForum.SendRequest();
	ResponseText = ResponseText + "";
	if(ResponseText=='true')
	{
		var url = "question.do?actionName=getForumTopicId&questionId="+qid;
		var topicIdAjaxObj = new AjaxAPI(url);
		var ResTextTopicId = topicIdAjaxObj.SendRequest();
		ResTextTopicId = ResTextTopicId + "";
		if(ResTextTopicId != 'null')
		{
			imagObj.src=imageUrl+"/images/btn_discussin_form.gif";
			document.getElementById("instanceId").value=testInstanceId;
			document.getElementById("questionId").value=qid;
			document.getElementById("forumTopicIdId").value=ResTextTopicId;
		
			checkDiv2(obj,  dropmenuID);
			//if(confirm("This question had sent on forum"))
			//{
				//window.location = forumBaseUrlRP + "posts/list/" + ResTextTopicId +".htm"
			//}
			//else
			//{
				//window.location = forumBaseUrlRP + "jforum.htm?module=posts&action=insertQuestion&qid=" + qid + "&testInstanceId="+testInstanceId + "&questionExistance=true";
			//}
		}
		else
		{
			url = "user.do?actionName=retriveBridgeInstance&fromAjax=true";
			var ajaxObj = new AjaxAPI(url);
			ajaxObj.SendRequest();
			window.location = forumBaseUrlRP + "jforum.htm?module=posts&action=insertQuestion&qid=" + qid + "&testInstanceId="+testInstanceId;
		}
	}
	else
	{
		imagObj.src=imageUrl+"/images/btn_discussin_form.gif";
		alert("Forum not available to discuss this question");
		return;
	}
}

function postOnExistanceForum(forumBaseUrlRP, action)
{
	var qid = document.getElementById("questionId").value;
	var testInstanceId = document.getElementById("instanceId").value;
	var topicId = document.getElementById("forumTopicIdId").value;
	
	var url = "user.do?actionName=retriveBridgeInstance&fromAjax=true";
	var ajaxObj = new AjaxAPI(url);
	ajaxObj.SendRequest();
	
	if(action=='new')
	{
		window.location = forumBaseUrlRP + "jforum.htm?module=posts&action=insertQuestion&qid=" + qid + "&testInstanceId="+testInstanceId + "&questionExistance=true";
	}
	else
	{
		window.location = forumBaseUrlRP + "posts/list/" + topicId +".htm"
	}
}

	
